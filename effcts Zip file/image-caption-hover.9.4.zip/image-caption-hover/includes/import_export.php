<div class="wrap">
	Get <a href="http://webcodingplace.com/wordpress-pro-plugins/image-caption-hover-pro-wordpress-plugin/" target="_blank">Pro Version</a>  to Unlock Import/Export Option
</div>